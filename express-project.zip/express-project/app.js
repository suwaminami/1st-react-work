// app.js

import express from "express";

const app = express();
const port = 3005;

// 編集
app.get("/", (req, res) => {
  res.json({
    uri: "/",
    message: "Hello Node.js!",
  });
});

// 追加
app.get("/omikuji", (req, res) => {
  res.json({
    uri: "/omikuji",
    message: "This is Omikuji URI!",
  });
});

// 追加
app.get("/janken", (req, res) => {
  res.json({
    uri: "/janken",
    message: "This is Janken URI!",
  });
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});

